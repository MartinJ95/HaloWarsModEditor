// normally this is defined by the IDE by "Using MFC" option but if it isn't
// (e.g. because we use bakefile-generated projects), do it ourselves to ensure
// that MFC libraries are linked in
#ifndef _AFXDLL
    #define _AFXDLL
#endif
#include <afxwin.h>
